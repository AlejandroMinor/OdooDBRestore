import OdooDBRestore

if __name__ == "__main__":  
    OdooDBRestore.OdooDBRestore().sequence_restore()